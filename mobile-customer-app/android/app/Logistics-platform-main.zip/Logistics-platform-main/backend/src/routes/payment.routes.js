const router = require('express').Router();
const ctrl = require('../controllers/payment.controller');
const { protect } = require('../middlewares/auth.middleware');

router.post('/create-order', protect, ctrl.createOrder);
router.post('/verify', ctrl.verify); // hit by the client callback
router.post('/webhook', ctrl.webhook); // hit by Razorpay's servers directly - signature-authenticated, not JWT
router.post('/refund', protect, ctrl.refund);
router.get('/history', protect, ctrl.history);

module.exports = router;
